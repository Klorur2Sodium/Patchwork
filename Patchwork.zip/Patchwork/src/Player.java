import java.util.Objects;
import java.util.Scanner;

public class Player {
	private QuiltBoard quiltBoard;
	private int nbButtonOnQuiltBoard;

	private int buttons;
	
	public QuiltBoard quiltboard() {
		return quiltBoard;
	}
	
	public Player (int buttons) {
		if (buttons < 0) {
			throw new IllegalArgumentException("The number of button must be positive");
		}

		this.buttons = Objects.requireNonNull(buttons);
		
		quiltBoard = new QuiltBoard();
		nbButtonOnQuiltBoard = 0;
	}
	
	// Methods - Ascii version
	public void selectPiece(Scanner scanner) {
		int userChoice;
		do {
			try {
				System.out.println("Enter 1, 2 or 3 to select the according piece or enter 0 if you don't want to buy any pieces");
				userChoice = Integer.parseInt(scanner.next());
			} catch (NumberFormatException e) {
				userChoice = -1;
			}
		} while (userChoice < 0 || userChoice > 3);
		
		System.out.println("fin");
	}
	
}


