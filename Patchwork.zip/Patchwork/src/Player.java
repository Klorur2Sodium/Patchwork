import java.util.Objects;

public class Player {
	private QuiltBoard quiltBoard;
	private int nbButtonOnQuiltBoard;

	private int buttons;
	
	public QuiltBoard quiltboard() {
		return quiltBoard;
	}
	
	public Player (int buttons) {
		if (buttons < 0) {
			throw new IllegalArgumentException("The number of button must be positive");
		}

		this.buttons = Objects.requireNonNull(buttons);
		
		quiltBoard = new QuiltBoard();
		nbButtonOnQuiltBoard = 0;
	}
	
}
